slices = int(input("How many pieces of cake have you eaten?: "))
calories_cake = slices * 225
km_needed = calories_cake/100
print("You must jog " + str(km_needed) + "KM to burn the calories")