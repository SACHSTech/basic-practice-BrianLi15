first_mark = int(input("Input first mark: "))

second_mark = int(input("Input second mark: "))

third_mark = int(input("Input third mark: "))

fourth_mark = int(input("Input fourth mark: "))

average = float(first_mark + second_mark + third_mark + fourth_mark) / 4
print("Your average is " + str(average))